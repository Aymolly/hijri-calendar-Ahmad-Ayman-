// ── أسماء الأشهر الهجرية ──
const HIJRI_MONTHS = [
  { en: "Muharram",        ar: "مُحرَّم"       },
  { en: "Safar",           ar: "صَفَر"         },
  { en: "Rabi' al-Awwal",  ar: "رَبيع الأوَّل"  },
  { en: "Rabi' al-Thani",  ar: "رَبيع الثَّاني" },
  { en: "Jumada al-Awwal", ar: "جُمادى الأُولى" },
  { en: "Jumada al-Thani", ar: "جُمادى الآخِرة" },
  { en: "Rajab",           ar: "رَجَب"         },
  { en: "Sha'ban",         ar: "شَعبان"        },
  { en: "Ramadan",         ar: "رَمَضَان"       },
  { en: "Shawwal",         ar: "شَوَّال"        },
  { en: "Dhu al-Qi'dah",  ar: "ذو القَعدة"    },
  { en: "Dhu al-Hijjah",  ar: "ذو الحِجَّة"   }
];

const GREG_MONTHS = [
  "January","February","March","April","May","June",
  "July","August","September","October","November","December"
];

const DAY_LABELS = ["أحد","اثنين","ثلاثاء","أربعاء","خميس","جمعة","سبت"];

// ── تحويل تاريخ ميلادي إلى Julian Day Number ──
function gregorianToJD(y, m, d) {
  if (m < 3) { y--; m += 12; }
  const A = Math.floor(y / 100);
  const B = 2 - A + Math.floor(A / 4);
  return Math.floor(365.25 * (y + 4716))
       + Math.floor(30.6001 * (m + 1))
       + d + B - 1524.5;
}

// ── تحويل Julian Day Number إلى تاريخ هجري ──
function jdToHijri(jd) {
  jd = Math.floor(jd) + 0.5;
  const z   = jd - 1948439.5;
  const cyc = Math.floor((z - 1) / 10631);
  let   n   = z - 10631 * cyc - 1;
  const j   = Math.floor((n - 29.5001) / 354.367);
  n         = n - 354 * j - Math.floor((3 + 11 * j) / 30);
  const hy  = 30 * cyc + j + 1;
  let   hm  = Math.floor((n - 1) / 29.5) + 1;
  if (hm > 12) hm = 12;
  const hd  = n - Math.floor(29.5001 * (hm - 1));
  return [hy, hm, Math.max(1, hd)];
}

// ── تحويل تاريخ هجري إلى Julian Day Number ──
function hijriToJD(hy, hm, hd) {
  return hd
    + Math.ceil(29.5 * (hm - 1))
    + Math.floor((hy - 1) * 354 + Math.floor((3 + 11 * hy) / 30))
    + 1948439.5 - 1;
}

// ── تحويل Julian Day Number إلى تاريخ ميلادي ──
function jdToGregorian(jd) {
  jd        = Math.floor(jd + 0.5);
  const a   = jd + 32044;
  const b   = Math.floor((4 * a + 3) / 146097);
  const c   = a - Math.floor(146097 * b / 4);
  const d2  = Math.floor((4 * c + 3) / 1461);
  const e   = c - Math.floor(1461 * d2 / 4);
  const m   = Math.floor((5 * e + 2) / 153);
  const day   = e - Math.floor((153 * m + 2) / 5) + 1;
  const month = m + 3 - 12 * Math.floor(m / 10);
  const year  = 100 * b + d2 - 4800 + Math.floor(m / 10);
  return [year, month, day];
}

// ── حساب عدد أيام شهر هجري ──
function hijriMonthLength(hy, hm) {
  const jd1 = hijriToJD(hy, hm, 1);
  const jd2 = (hm < 12) ? hijriToJD(hy, hm + 1, 1) : hijriToJD(hy + 1, 1, 1);
  return Math.round(jd2 - jd1);
}

// ── الحالة الحالية ──
const today = new Date();
const [curHY, curHM, curHD] = jdToHijri(
  gregorianToJD(today.getFullYear(), today.getMonth() + 1, today.getDate())
);
let viewHY = curHY;
let viewHM = curHM;

// ── رسم التقويم ──
function render() {
  const mlen = hijriMonthLength(viewHY, viewHM);
  const jd1  = hijriToJD(viewHY, viewHM, 1);
  const [gy1, gm1, gd1] = jdToGregorian(jd1);
  const firstDow = new Date(gy1, gm1 - 1, gd1).getDay();

  const jdLast = hijriToJD(viewHY, viewHM, mlen);
  const [gyL, gmL] = jdToGregorian(jdLast);

  // ─ تحديث رأس التقويم ─
  document.getElementById("hc-hijri-full").textContent =
    HIJRI_MONTHS[viewHM - 1].ar + " " + viewHY + " هـ";
  document.getElementById("hc-greg-sub").textContent =
    GREG_MONTHS[gm1 - 1] + " " + gy1 + " – " + GREG_MONTHS[gmL - 1] + " " + gyL;
  document.getElementById("hc-month-name").textContent =
    HIJRI_MONTHS[viewHM - 1].en;
  document.getElementById("hc-year-disp").textContent =
    viewHY + " AH";

  // ─ تحديث ذيل التقويم ─
  const todayJD = gregorianToJD(
    today.getFullYear(), today.getMonth() + 1, today.getDate()
  );
  const [tHY, tHM, tHD] = jdToHijri(todayJD);
  document.getElementById("hc-today-label").textContent =
    tHD + " " + HIJRI_MONTHS[tHM - 1].en + " " + tHY + " AH";

  let html = "";

  // ─ عناوين أيام الأسبوع ─
  DAY_LABELS.forEach(function(d) {
    html += '<div class="hc-day-label">' + d + '</div>';
  });

  // ─ أيام من الشهر السابق ─
  const prevHM  = viewHM > 1 ? viewHM - 1 : 12;
  const prevHY  = viewHM > 1 ? viewHY : viewHY - 1;
  const prevLen = hijriMonthLength(prevHY, prevHM);
  for (var i = 0; i < firstDow; i++) {
    var dn = prevLen - (firstDow - 1 - i);
    html += '<div class="hc-day other-month">' + dn + '</div>';
  }

  // ─ أيام الشهر الحالي ─
  for (var d = 1; d <= mlen; d++) {
    var jd    = hijriToJD(viewHY, viewHM, d);
    var dow   = Math.round(jd + 1.5) % 7;
    var isToday = (viewHY === curHY && viewHM === curHM && d === curHD);
    var isFri   = (dow === 5);
    var cls = "hc-day";
    if (isToday) cls += " today";
    if (isFri)   cls += " friday";
    html += '<div class="' + cls + '">' + d + '</div>';
  }

  // ─ أيام من الشهر التالي ─
  var totalCells = Math.ceil((firstDow + mlen) / 7) * 7;
  var trailing   = totalCells - (firstDow + mlen);
  for (var t = 1; t <= trailing; t++) {
    html += '<div class="hc-day other-month">' + t + '</div>';
  }

  document.getElementById("hc-grid").innerHTML = html;
}

// ── التنقل بين الشهور ──
function hcChange(dir) {
  viewHM += dir;
  if (viewHM > 12) { viewHM = 1;  viewHY++; }
  if (viewHM < 1)  { viewHM = 12; viewHY--; }
  render();
}

// ── تشغيل التقويم ──
render();
